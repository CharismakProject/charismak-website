import type { GameState } from "./types.ts";

export interface SaveEnvelope {
  saveSchemaVersion: 1;
  savedAt: string;
  state: GameState;
}

export function serializeState(state: GameState, savedAt = new Date().toISOString()): string {
  const envelope: SaveEnvelope = {
    saveSchemaVersion: 1,
    savedAt,
    state,
  };
  return JSON.stringify(envelope);
}

export function deserializeState(payload: string): GameState {
  const parsed = JSON.parse(payload) as Partial<SaveEnvelope>;
  if (parsed.saveSchemaVersion !== 1) {
    throw new Error("Unsupported save schema version.");
  }
  if (!parsed.state || parsed.state.schemaVersion !== 1) {
    throw new Error("Invalid game state in save.");
  }
  return parsed.state;
}

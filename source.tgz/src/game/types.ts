export type GameStage =
  | "command_centre"
  | "tender"
  | "contract_awarded"
  | "mobilised"
  | "construction";

export type OpportunityStatus = "available" | "bid_submitted" | "awarded";
export type TenderStatus = "submitted" | "awarded";
export type ProjectStatus = "awarded" | "mobilised" | "in_progress";
export type ActivityStatus = "ready" | "in_progress" | "complete" | "blocked";
export type LedgerKind = "cash_in" | "material" | "delivery" | "labour" | "mobilisation";

export interface CompanyState {
  id: string;
  name: string;
  location: "Abuja, Nigeria";
  cash: number;
  reputation: number;
}

export interface OpportunityState {
  id: string;
  title: string;
  client: string;
  location: string;
  summary: string;
  recommendedBid: number;
  status: OpportunityStatus;
}

export interface TenderState {
  id: string;
  opportunityId: string;
  bidAmount: number;
  submittedOn: string;
  status: TenderStatus;
}

export interface MaterialRequirement {
  materialId: string;
  quantity: number;
}

export interface ActivityState {
  id: string;
  name: string;
  status: ActivityStatus;
  progress: number;
  baseDurationDays: number;
  productivityFactor: number;
  weight: number;
  crewId: string;
  materials: MaterialRequirement[];
  materialsIssued: boolean;
}

export interface ProjectState {
  id: string;
  opportunityId: string;
  title: string;
  client: string;
  location: string;
  contractValue: number;
  mobilisationPaymentPct: number;
  status: ProjectStatus;
  progress: number;
  activities: ActivityState[];
}

export interface InventoryItemState {
  materialId: string;
  name: string;
  unit: string;
  quantity: number;
  averageUnitCost: number;
}

export interface CrewState {
  id: string;
  name: string;
  workers: number;
  dailyCost: number;
  competence: number;
  reliability: number;
}

export interface LedgerEntry {
  id: string;
  date: string;
  kind: LedgerKind;
  description: string;
  amount: number;
  projectId?: string;
}

export interface InboxItem {
  id: string;
  date: string;
  title: string;
  body: string;
  severity: "info" | "attention" | "success";
}

export interface GameEvent {
  id: string;
  date: string;
  type: string;
  message: string;
}

export interface GameState {
  schemaVersion: 1;
  engineVersion: "0.1.0";
  contentVersion: string;
  careerId: string;
  gameDate: string;
  stage: GameStage;
  company: CompanyState;
  opportunities: OpportunityState[];
  tenders: TenderState[];
  projects: ProjectState[];
  inventory: InventoryItemState[];
  crews: CrewState[];
  ledger: LedgerEntry[];
  inbox: InboxItem[];
  events: GameEvent[];
}

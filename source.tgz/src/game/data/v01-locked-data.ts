import type { ActivityState, CrewState, OpportunityState } from "../types.ts";

/**
 * CM-008 — authoritative V0.1 balancing data for the current first-playable slice.
 * Source of truth: locked 02 — CONSTRUCTION ENGINE CM-008 dataset.
 *
 * No development-only balancing values belong in the engine. The wider locked
 * renovation catalogue remains data-owned and is consumed incrementally as
 * later already-approved engine mechanics are implemented.
 */
export const CM008_LOCKED = {
  id: "CM-008-RENOVATION-V01",
  version: "0.1.0",
  contentVersion: "v0.1-cm008-locked-1",
  currency: "NGN",
  timezone: "Africa/Lagos",
  rng: {
    algorithm: "mulberry32",
    version: 1,
    defaultSeed: 1101,
  },
  company: {
    startingCash: 650_000,
    startingReputation: 0,
  },
  project: {
    id: "PRJ-REN-001",
    templateId: "V01-SMALL-RENOVATION",
    name: "Small Renovation — Abuja",
    location: "Abuja, FCT, Nigeria",
    siteAreaM2: 58,
    siteCondition: "NORMAL",
    contractStartDate: "2026-09-07",
    plannedWorkingDays: 20,
    plannedCompletionDate: "2026-09-29",
    workingDays: ["MON", "TUE", "WED", "THU", "FRI", "SAT"],
    nonWorkingDays: ["SUN"],
    contract: {
      originalValue: 4_800_000,
      approvedVariations: 0,
      currentValue: 4_800_000,
      paymentMilestones: [
        {
          id: "PAY-REN-MOB",
          name: "Mobilisation",
          percent: 35,
          amount: 1_680_000,
          trigger: "CONTRACT_AWARD",
          processingWorkdays: 0,
        },
        {
          id: "PAY-REN-MID",
          name: "First-fix milestone",
          percent: 35,
          amount: 1_680_000,
          trigger: "INSPECTION_PASS:INSP-REN-FIRSTFIX",
          processingWorkdays: 1,
        },
        {
          id: "PAY-REN-FINAL",
          name: "Practical completion",
          percent: 30,
          amount: 1_440_000,
          trigger: "INSPECTION_PASS:INSP-REN-FINAL",
          processingWorkdays: 2,
        },
      ],
    },
    balanceTargets: {
      cashAvailableImmediatelyAfterMobilisation: 2_330_000,
      baselineMaterialPurchaseCost: 2_814_100,
      baselineLabourCost: 742_000,
      baselineDeliveryCost: 189_000,
      baselineDirectCost: 3_745_100,
      baselineForecastProfit: 1_054_900,
      baselineForecastMarginPct: 22,
      targetCompletionWorkingDays: 20,
      tutorialDifficulty: "FORGIVING_BUT_CASH_SENSITIVE",
    },
  },
  gradeProfiles: {
    BASIC: {
      dailyRateMultiplier: 0.8,
      productivityMultiplier: 0.82,
      qualityRiskMultiplier: 1.25,
      reliabilityScore: 0.9,
    },
    STANDARD: {
      dailyRateMultiplier: 1,
      productivityMultiplier: 1,
      qualityRiskMultiplier: 1,
      reliabilityScore: 0.96,
    },
    SKILLED: {
      dailyRateMultiplier: 1.25,
      productivityMultiplier: 1.15,
      qualityRiskMultiplier: 0.75,
      reliabilityScore: 0.98,
    },
  },
  crews: {
    general: {
      id: "CREW-GENERAL",
      trade: "GENERAL_LABOUR",
      name: "General Labour Crew",
      composition: [{ role: "Labourer", count: 3 }],
      standardDailyRate: 20_000,
    },
    mason: {
      id: "CREW-MASON",
      trade: "MASON",
      name: "Mason Crew",
      composition: [{ role: "Mason", count: 1 }, { role: "Labourer", count: 2 }],
      standardDailyRate: 26_000,
    },
    electrician: {
      id: "CREW-ELECTRICIAN",
      trade: "ELECTRICIAN",
      name: "Electrical Crew",
      composition: [{ role: "Electrician", count: 1 }, { role: "Assistant", count: 1 }],
      standardDailyRate: 23_000,
    },
    plumber: {
      id: "CREW-PLUMBER",
      trade: "PLUMBER",
      name: "Plumbing Crew",
      composition: [{ role: "Plumber", count: 1 }, { role: "Assistant", count: 1 }],
      standardDailyRate: 22_000,
    },
    ceiling: {
      id: "CREW-CEILING",
      trade: "CEILING",
      name: "Ceiling Crew",
      composition: [{ role: "Ceiling installer", count: 1 }, { role: "Assistant", count: 1 }],
      standardDailyRate: 28_000,
    },
    tiler: {
      id: "CREW-TILER",
      trade: "TILER",
      name: "Tiling Crew",
      composition: [{ role: "Tiler", count: 1 }, { role: "Assistant", count: 1 }],
      standardDailyRate: 26_000,
    },
    painter: {
      id: "CREW-PAINTER",
      trade: "PAINTER",
      name: "Painting Crew",
      composition: [{ role: "Painter", count: 1 }, { role: "Assistant", count: 1 }],
      standardDailyRate: 22_000,
    },
    fitter: {
      id: "CREW-FITTER",
      trade: "FITTER",
      name: "Fixtures/Fittings Crew",
      composition: [{ role: "Installer", count: 1 }, { role: "Assistant", count: 1 }],
      standardDailyRate: 22_000,
    },
  },
  firstActivityDefinition: {
    id: "REN-001",
    name: "Mobilisation & Protection",
    phase: "MOBILISATION",
    kind: "ACTIVITY",
    quantity: 1,
    unit: "LS",
    baseProductivityPerStandardCrewDay: 1,
    plannedDurationWorkdays: 1,
    crewId: "CREW-GENERAL",
    recipeId: "REC-REN-PROTECT",
    predecessors: [] as string[],
    weatherSensitive: false,
    qualityRisk: "LOW",
    defaultReworkFraction: 0,
    initialStatus: "READY",
  },
  firstRecipe: {
    id: "REC-REN-PROTECT",
    items: [{ materialId: "MAT-PROTECT-PACK", qtyPerActivityUnit: 1 }],
  },
  firstMaterial: {
    id: "MAT-PROTECT-PACK",
    name: "Protection & masking consumables",
    category: "GENERAL",
    baseUnit: "pack",
    purchaseUnit: "pack",
    baseQtyPerPurchaseUnit: 1,
    baselineWasteRate: 0,
    storageRisk: "LOW",
  },
  firstSupplier: {
    id: "SUP-SITECARE",
    name: "SiteCare Abuja",
    categories: ["GENERAL"],
    reliability: "HIGH",
    reliabilityScore: 0.97,
    defaultDeliveryFee: 15_000,
  },
  firstSupplierOffer: {
    id: "OFF-PROTECT-SITE",
    supplierId: "SUP-SITECARE",
    materialId: "MAT-PROTECT-PACK",
    pricePerPurchaseUnit: 110_000,
    leadTimeWorkdays: 0,
    qualityGrade: "STANDARD",
    availablePurchaseUnits: 10,
  },
  firstProcurementBatch: {
    id: "BATCH-REN-MOB",
    trigger: "BEFORE_REN-001",
    supplierId: "SUP-SITECARE",
    materials: ["MAT-PROTECT-PACK"],
    deliveryFee: 15_000,
  },
  goldenScenario: {
    id: "REN-SEED-1101-HAPPY",
    seed: 1101,
    expectedCompletionWorkingDays: 20,
    cashNeverNegativeWithRecommendedBatches: true,
  },
} as const;

const standardGrade = CM008_LOCKED.gradeProfiles.STANDARD;
const generalCrew = CM008_LOCKED.crews.general;
const firstActivity = CM008_LOCKED.firstActivityDefinition;
const firstMaterial = CM008_LOCKED.firstMaterial;
const firstOffer = CM008_LOCKED.firstSupplierOffer;

export const V01_LOCKED_SEED = {
  contentVersion: CM008_LOCKED.contentVersion,
  gameStartDate: CM008_LOCKED.project.contractStartDate,
  projectId: CM008_LOCKED.project.id,
  workingDays: CM008_LOCKED.project.workingDays,
  startingCash: CM008_LOCKED.company.startingCash,
  startingReputation: CM008_LOCKED.company.startingReputation,
  firstOpportunity: {
    id: "OPP-REN-001",
    title: CM008_LOCKED.project.name,
    client: "Private Client",
    location: CM008_LOCKED.project.location,
    summary: "A compact Abuja renovation introducing tendering, mobilisation, labour, materials and cash-flow control.",
    recommendedBid: CM008_LOCKED.project.contract.currentValue,
    status: "available",
  } satisfies OpportunityState,
  mobilisation: {
    paymentPct: CM008_LOCKED.project.contract.paymentMilestones[0].percent / 100,
    paymentAmount: CM008_LOCKED.project.contract.paymentMilestones[0].amount,
    starterMaterial: {
      materialId: firstMaterial.id,
      name: firstMaterial.name,
      unit: firstMaterial.baseUnit,
      purchaseQuantity: 1,
      unitCost: firstOffer.pricePerPurchaseUnit,
      deliveryFee: CM008_LOCKED.firstProcurementBatch.deliveryFee,
      supplierName: CM008_LOCKED.firstSupplier.name,
    },
  },
  starterCrew: {
    id: generalCrew.id,
    name: generalCrew.name,
    workers: generalCrew.composition.reduce((sum, item) => sum + item.count, 0),
    dailyCost: generalCrew.standardDailyRate * standardGrade.dailyRateMultiplier,
    competence: standardGrade.productivityMultiplier,
    reliability: standardGrade.reliabilityScore,
  } satisfies CrewState,
  firstActivity: {
    id: firstActivity.id,
    name: firstActivity.name,
    status: "ready",
    progress: 0,
    baseDurationDays: firstActivity.plannedDurationWorkdays,
    productivityFactor: standardGrade.productivityMultiplier,
    weight: (firstActivity.plannedDurationWorkdays / CM008_LOCKED.project.plannedWorkingDays) * 100,
    crewId: firstActivity.crewId,
    materials: [{ materialId: firstMaterial.id, quantity: 1 }],
    materialsIssued: false,
  } satisfies ActivityState,
} as const;
